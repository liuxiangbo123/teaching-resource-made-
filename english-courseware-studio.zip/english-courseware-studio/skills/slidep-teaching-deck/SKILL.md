---
name: slidep-teaching-deck
description: 用 @tencent/slidep（SlideDSL）从零构建中文教学课件 .pptx 的完整工作流，含 <Animation> 动画窗格（p:timing）配法与本机环境坑位（Bash 损坏、PowerShell stdout 不回传、图片按 CWD 解析、safe-delete 拦截、批量 upsert 超时）。当需要用 slidep 生成/修改 pptx 课件，或遇到 slidep 报 ENOENT / overflow / commitrevision 500 诊断时使用。
agent_created: true
---

# slidep 教学课件生成工作流

## 适用场景
用 `@tencent/slidep` 把 SlideDSL（JSX-like 受限 DSL）编译成真实 `.pptx`，典型用于生成教学课件（封面/目录/章节扉页/内容页/结束页的完整叙事结构）。

## 本机环境（Windows）必须先知道的四件事

1. **Bash 完全损坏** — 任何 Bash 调用都报 `dirname: command not found` / `cd: null directory`。**一律改用 PowerShell**。
2. **PowerShell stdout 不回传** — 命令能真正执行，但工具只返回 "Command completed with exit code N"，看不到输出。变通：把结果 `Out-File` 到文件，再用 `Read` 工具读该文件。
3. **图片路径按 CWD 解析** — DSL 里写 `src='assets/xxx.png'`，所以 `lint` / `upsert-dsl` **必须先在项目目录下 `Set-Location`**，否则报 ENOENT。注意：即使 node 进程的 CWD 对了，也要确认命令里的 pptx 路径是绝对路径。
4. **safe-delete 拦截删除** — `Remove-Item` 会报 `SAFE_DELETE_FAIL_CLOSED / trash-failed`，删不掉文件（有时第二次调用会成功，但不保证）。不要为了清理临时文件浪费轮次，直接把日志写到专门目录或干脆忽略。

## 命令范式（PowerShell）

```powershell
$nd="C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3"
$prj="<项目绝对路径>"
Set-Location $prj
$slidep="$nd\node_modules\@tencent\slidep\dist\index.js"

# 1) 新建 pptx（可带 --dsl-file 预置页）
& "$nd\node.exe" $slidep create "$prj\deck.pptx"

# 2) 校验单页（一定先 lint 再 upsert）
& "$nd\node.exe" $slidep lint "$prj\deck.pptx" --dsl-file "$prj\slides\01.slide"

# 3) 写入/替换某一页
& "$nd\node.exe" $slidep upsert-dsl "$prj\deck.pptx" --dsl-file "$prj\slides\01.slide"
```

输出为 JSON：`{"ok":true,"page_index":0,"slide_count":1,"diagnostics":[]}`。`diagnostics` 非空即有问题。

## 关键坑位

- **`upsert-dsl` 是「追加」语义，不是「按页码更新」**：`create` 得到一个 deck 后，必须严格按 `01→42` 顺序逐页 upsert（一个 `.slide` 调用 = 追加一页）。**页序的唯一来源就是这个调用顺序**。若中途某页没真正入包（create 参数写错、批次被杀），成品会静默缺页，而且**无法靠"补 upsert 缺失页"修复顺序** —— 只能 `create` 一个新文件后按顺序全量重建。防御：**每批 upsert 完立刻用 zipfile 数 `ppt/slides/slideN.xml` 数量**，不要等 42 页全跑完才查。
- **批量 upsert 会超时**：一个 `foreach` 循环连续跑 20+ 页，进程会在中途被杀（表现为日志只写到一半、exit code 1）。**每批 ≤ 12 页**，或逐页单独调用。
- **overflow 诊断**：`child-containment: Child element exceeds parent by bottom+Npx` 大多由「`flex:1` 的列容器 + 内部固定高度子元素」相加超限引起。修法：把固定高子元素改小 / 改成 `flex` 分配，或用 `justifyContent:'space-between'` 让容器自己吸收余量。
- **A 区英文小标（16px 等宽）长度上限约 50 字符**：超出会**误报** `child-containment ... top+6px / bottom+6px`，诊断指向 A 区那两个 `Text`，但 A 区实际高度（32×1.2 + 6 + 16×1.3 ≈ 65px）远没超 80px。**这不是真溢出**，把小标压缩到 50 字符以内即可通过（例如 53→37 字符后立即 ok）。
- **lint 是单页独立校验**：`slide_count` 恒为 1、`page_index` 恒为 0，不代表整份文件的页数。**要确认总页数，用 Python zipfile 数 `ppt/slides/slideN.xml`**。
- **图片实际落点**：slidep 把媒体放在 `ppt/slides/media/`（非 OOXML 惯例的 `ppt/media/`），rels 指向正确，Office/WPS 能正常打开。不要因为找不到 `ppt/media/` 就以为图片没嵌进去。
- **反查某页用了哪张图**：读 `ppt/slides/_rels/slideN.xml.rels`，正则用 `Target="[^"]*media/[^"]+"`（Target 形如 `media/image1.png`，**不带 `../`**；用 `\.\./media/` 会全部匹配不到，误判成"没配图"）。交付前逐页核一遍：DESIGN 声明了配图却漏进 slide 是极常见的静默错误。
- **FAIcon**：`<FAIcon name='home' style={{fill:'#1F3B4D', width:22, height:22}} />`，会被转成 svg 独立文件。同一卡片组尺寸必须一致。
- 输出日志里的中文路径常显示为乱码（`澶栫爺鐗堝叓骞寸骇`），是 Out-File 编码问题，**不影响实际执行**，不要据此判定路径错了。

## 动画（动画窗格 / `<Animation>`）

`<Animation>` 是**真正写入 OOXML `<p:timing>` 时间轴**的动画，PowerPoint / WPS 的「动画窗格」可见，不依赖插件。

```jsx
<Animation animType="fadeIn" duration={500} delay={200} direction="up">
    <Box style={{ ... }}> ... </Box>
</Animation>
```

- 属性：`animType`（必填）、`startType` ∈ `click`(默认) / `withPrevious` / `afterPrevious`、`duration`（默认 500ms）、`delay`、`direction`
- 依赖版本：**slidep 0.4.4-alpha 及以上**（下面提到的 500 报错用 `upgrade` 修复）
- 每个 `<Animation>` 必须**恰好包住一个直接子元素**

### 硬约束（踩过的坑）

1. **`<Animation>` 不能包住"内容复杂的容器"** —— 含 8 个以上子元素、或内部有多个固定高度占位 `Box` 的卡片包进去会触发**服务器端编译缺陷**：

   ```
   Error: /localapi/commitrevision HTTP 500:
   {"error":"CommitRevision failed: [13043] mutation invalid: shape not found, ... check fail"}
   ```

   这个报错**在全新 `create` 的空文件上同样复现**（所以不是修订链脏了），且 `lint` 仍返回 `ok:true`（lint 只查语法、不查编译）。**修法：动画只包住内容简单的块**（一个 `Text`、一个装 2–3 个子元素的 `Box`），不要包整张卡片。

2. **一个 `<Animation>` 包整卡会展开成大量碎片条目**。实测：包一张含 7 个子元素的卡 → 动画窗格出现 **8 条**独立 `withEffect` 条目。所以**"动画一个卡片"≠"动画窗格一条"**。要窗格干净，就动画卡片内**最小的语义单元**（例如只动画答案条 / 序号方块），而不是整卡。

3. **`afterPrevious` 语义已验证可用**：产物中它的 `nodeType="afterEffect"` 且**不计入"独立点击组"**，即真的"上一动画播完自动接上"（`<p:cond delay="N"/>`），不需要点击。

### 判定动画是否真的写进去

```python
import zipfile, re
z = zipfile.ZipFile("deck.pptx")
x = z.read("ppt/slides/slide3.xml").decode("utf-8", "ignore")
print("<p:timing>" in x)                                  # 是否有动画时间轴
print(re.findall(r'presetID="(\d+)"[^>]*presetClass="(\w+)"[^>]*grpId="(\d+)"[^>]*nodeType="(\w+)"', x))
```

- `presetClass="entr"` = 入场；`presetID="10"` = 淡入（`fadeIn`），`"22"` = 擦除（`wipe`）
- 按 `grpId` 归组 = 动画窗格里的组数。**`nodeType="withEffect"` 不带 `afterEffect` 的组 = 一次点击推进一组**
- 校验动画组数：`len(set(grpId))`，单页建议 ≤4

### 动画设计原则（教学课件）

- **不是每页都要动画**（全篇 30–45% 的页有即可），优先：封面/章节扉页、关键数字揭示、**提问页的答案**
- **答案默认隐藏、点击后出现**是课堂问答的标准节奏；`delay 100–300ms` 让答案与问题拉开层次
- 全篇统一一种入场风格（要么都 `fadeIn`，要么都 `flyIn`）
- **页脚、页码、A 区标题不加动画**
- 答案页的视觉签名：熟铜浅底 `rgba(193,102,47,0.10)` 的块 = 答案块，就是该动画的目标

## 什么时候必须重建整个 deck

`upsert-dsl` 用 `--page-index <0-based N>` 是**替换**、省略或 `-1` 是**追加**。以下两种情况**不要试图逐页修补，直接 `create` 新文件按 1→N 顺序全量重建**：

- 某页 `upsert` 失败后，后续页仍追加成功 → 该页缺失/错位，页序整体偏移
- `commitrevision HTTP 500` 反复出现且换 DSL 也无法绕过 → 修订链已脏

> 注意：`--page-index` 传错会**静默替换掉别的页**（曾导致成品从 42 页变成 36 页）。替换时务必 `页号 - 1`。

## 依赖升级

slidep 是 alpha 包，老版本可能缺 `<Animation>` 支持或行为不同。升级：

```powershell
$nd="C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3"
& "$nd\npm.cmd" install -g --prefix "$nd" "@tencent/slidep@latest"
```

升级后**必须先写一个最小探针页验证**（一个 `<Animation>` + `fadeIn`）再批量应用，不要直接改 40 页。


## 语言改造：把中文课件换成地道英文

教师常反馈"汉语表述太多，不像英语课件"。**不要用 `tencent-local-office-edit` 的 `slide_find_replace_text`** —— 它的文档明写"每个受影响形状的 run 级样式（bold/italic/color/font/size）会被重置"，且不穿透组合形状、表格单元格、图表文字，还要逐页传 `page_index`。对精心排版 + 带动画时间轴的课件等于毁容。
**正确做法：改 `slides/*.slide` 源码里 `<Text>` 节点的内文，再 `create` + 顺序全量 upsert 重建。** 样式与 `<p:timing>` 动画 100% 保留。

替换脚本要点（比子串替换安全得多）：

```python
def replace_inner(line, new_inner):
    i = line.find("<Text")
    j = line.find(">", i)          # 第一个 <Text ...> 标签闭合
    k = line.rfind("</Text>")      # 该行最后一个 </Text>（兼容内嵌 <Text>/<span>）
    return line[:j+1] + new_inner + line[k:]
```

- **按行号定位**（行号从"只打印含中文的行"的 dump 里取），一次改一行；**自下而上**改，避免行号漂移。
- 每行先断言 `含汉字`；但**只有全角空格 `\u3000`、没有汉字的行会被漏掉**，要单独兜一次。
- 改写原则：
  - 中文课件常是**双语**结构（中文当教学语言、英文做术语 gloss）。改成全英文后"英文术语 + 中文释义"会自我重复 → 统一改成"英文术语 + **英文短释义**"。
  - 长度预算：同字号下英文视觉宽度约等于汉字的一半 → 译文控制在中文的 **≤1.8 倍**，先按行数估再压。
  - kicker 统一大写（`本节回顾`→`RECAP`、`答案`→`ANSWERS`、`你可以这样用`→`IN USE`）。
  - 顺手去掉字体栈里的 `"微软雅黑"`。
- 改前先 `cp -r slides _slides_zh_bak` 留底。

## 交付前怎么验证（本机无渲染器）

本机**没有 LibreOffice / 没有可用 PowerPoint 路径**，`slidep screenshot` 也不可用（报 `Received 'file:///workspace/node_modules/...'`，SDK 路径写死成 Linux，Windows 下必挂，别试）。用这三招代替目视：

1. **逐页 `lint`（唯一能抓真实溢出的工具）**
   `slidep lint <pptx> --dsl-file slides/NN.slide --page-index N-1`，看 `diagnostics` 是否为空。
   典型报错 `child-containment: Child element exceeds parent container by bottom+47px` = 文案变长把卡片撑爆，**收短该页文案**即可。lint 只查语法层面，能抓到容器溢出，抓不到"看起来挤不挤"。
2. **文本度量脚本（PIL + `C:/Windows/Fonts/msyh.ttc` / `consola.ttf`）**
   按 **(页, 页内第 N 个文字形状)** 把两版配对（形状数应逐页一致），算折行数与"需高/框高"。
   ⚠️ **判读陷阱**：单行标签的"需高/框高 ≈ 1.65"是**正常比例**（用原版里一句纯英文 `Introducing the new ___!` 验证过），不要按比值报警；**只看"旧版没问题、新版超了"的新增项**。按形状索引配对时，若两版形状数不同则对比无效。
3. **页级越界**：取每页**含可见文字**形状的 `y+cy` 最大值，必须 `≤ 720`（排除整页容器形状，否则恒等于 720）。宽 1280 同理。

另外两个便宜又有效的检查：`ppt/slides/slideN.xml` 数量 = 设计页数；`<a:t>` 里 `[\u4e00-\u9fff]` 命中数 = 0（语言改造后）。

## 交付前先做"文件考古"

用户 @ 的文件**不一定是最新稿**。动手前比一比：文件大小 / md5 / `docProps/app.xml` 的 `Application`（`Tencent office` = slidep 产物；`Microsoft Office PowerPoint` = 用户自己另存过）/ 页数 / `mtime`。
曾遇到：用户 @ 的桌面 `副本.pptx` 只有 41 页、无动画、被 PowerPoint 另存过（mtime 就在提问前 3 分钟），而工程里的才是 42 页带 17 页动画的最新稿。**按最新稿做，桌面那份别覆盖，交付时说明版本关系。**

## 推荐工作流（教学课件）

1. **先写两份契约再写代码**：`STORY.md`（逐页叙事大纲：标题句/type/rhythm/layout/visual/anti_pattern/description）+ `DESIGN.md`（配色 hex 白名单、字体两族、字号阶梯、A/B/C 三区母版硬约束、页面映射表）。逐页 .slide 一律以 DESIGN.md 为唯一取值依据。
2. **三区母版硬约束**（1280×720，padding `20px 70px`）：
   - A 标题块 `height:80`，中文 32px bold + 英文小标 17px
   - 间隔 `height:12`
   - B 内容区 `height:540`
   - 间隔 `height:12`
   - C 页脚条 `height:36`（左 `Unit x · ...`，右 `NN / 总页数`，均 13px）
   - 合计 80+12+540+12+36 = 680 = 720-40 ✓
   - 封面/章节扉页/结束页可省略 C 区，用 `padding:0` + 绝对定位。
3. **版式要轮换**：相邻页版式不得相同；`N卡片横排`（等宽横排）全篇 ≤2 页，避免"卡片墙"。
4. **每页写完立刻 lint**，通过后再 upsert；全部写完用 zipfile 复核页数。

## 自检清单（交付前）

- [ ] `ppt/slides/` 下 slideN.xml 数量 = 设计页数
- [ ] **每页标题与实际设计页号一一对应**（防止 upsert 错位导致的静默页序偏移）
- [ ] 每页 `lint` 的 `diagnostics` 为空
- [ ] 每页使用的图片与 DESIGN 图片清单一致（读 `ppt/slides/_rels/slideN.xml.rels`，正则 `Target="[^"]*media/[^"]+"`，**不带 `../`**）
- [ ] 相邻页版式不重复；等宽横排 ≤2 页
- [ ] 中文字体已显式声明 `"Microsoft YaHei","微软雅黑"`，英文衬线用 `Georgia`
- [ ] **若配了动画**：含 `<p:timing>` 的页与 DESIGN 动画清单一致；单页 `grpId` 组数 ≤4；页脚/页码/标题无动画
- [ ] 交付说明里写明查看动画的方式（PowerPoint/WPS → `动画` → `动画窗格`；放映后点击推进）
- [ ] **若做了语言改造**：`<a:t>` 里汉字命中数 = 0；每页文字形状数与改造前一致；每页 `lint` 诊断为空；每页文字形状下沿 ≤720
