#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
render_pptx.py —— pptx 逐页渲染为 PNG（供排版目检 / 验收指标 3 使用）

原理：调用本机 PowerPoint 的 COM 接口导出图片（ppSaveAsPNG=18）。
      这是本机唯一可用的 pptx 渲染路径；slidep screenshot 在 Windows 下不可用。

用法：
    python render_pptx.py <课件.pptx> --out <输出目录> [--prefix p] [--keep-raw]

输出：
    <输出目录>/p001.png, p002.png ...   （按页序，三位补零）
    <输出目录>/_render_log.txt          （渲染日志；PowerShell stdout 不回传，故落盘）

注意：
    - pptx 路径与输出目录可含中文，路径通过环境变量传递，避开命令行编码问题。
    - 不修改源 pptx（Open 时 ReadOnly=True）。
    - 渲染前请确认没有同名 PowerPoint 进程占用该文件。
"""
import argparse
import os
import subprocess
import sys
import glob
import shutil
import re

PS_TEMPLATE = r'''
$ErrorActionPreference = "Stop"
$log = $env:RPT_LOG
function L($m) { Add-Content -Path $log -Value $m -Encoding UTF8 }
try {
    L "START"
    $app = New-Object -ComObject PowerPoint.Application
    L ("APP " + $app.Version)
    $pres = $app.Presentations.Open($env:RPT_SRC, $true, $false, $false)
    L ("OPENED slides=" + $pres.Slides.Count)
    if (Test-Path $env:RPT_RAW) { Remove-Item $env:RPT_RAW -Recurse -Force }
    $pres.SaveCopyAs($env:RPT_RAW, 18)
    L "EXPORTED"
    $pres.Close()
    $app.Quit()
    L "DONE"
} catch {
    L ("ERROR " + $_.Exception.Message)
    try { $app.Quit() } catch {}
    exit 1
}
'''


def run(src: str, outdir: str, prefix: str = "p", keep_raw: bool = False) -> int:
    if not os.path.isfile(src):
        print("[x] 找不到 pptx: %s" % src)
        return 2
    os.makedirs(outdir, exist_ok=True)
    rawdir = os.path.join(outdir, "_raw")
    log = os.path.join(outdir, "_render_log.txt")
    if os.path.exists(log):
        os.remove(log)

    env = dict(os.environ)
    env["RPT_SRC"] = os.path.abspath(src)
    env["RPT_RAW"] = os.path.abspath(rawdir)
    env["RPT_LOG"] = os.path.abspath(log)

    # 先写临时 ps1（内容纯 ASCII，路径全靠环境变量）
    ps1 = os.path.join(outdir, "_render.ps1")
    with open(ps1, "w", encoding="utf-8-sig", newline="\r\n") as f:
        f.write(PS_TEMPLATE)

    proc = subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive",
         "-ExecutionPolicy", "Bypass", "-File", ps1],
        env=env, capture_output=True, text=True,
    )

    if not os.path.isdir(rawdir):
        print("[x] 导出失败，日志：")
        if os.path.exists(log):
            print(open(log, encoding="utf-8", errors="replace").read())
        print(proc.stdout, proc.stderr)
        return 3

    # 归一化文件名：幻灯片1.png -> p001.png
    files = [f for f in os.listdir(rawdir) if f.lower().endswith((".png", ".jpg"))]

    def key(name):
        m = re.search(r"(\d+)", name)
        return int(m.group(1)) if m else 0

    files.sort(key=key)
    made = []
    for i, f in enumerate(files, 1):
        ext = os.path.splitext(f)[1].lower()
        dst = os.path.join(outdir, "%s%03d%s" % (prefix, i, ext))
        shutil.move(os.path.join(rawdir, f), dst)
        made.append(os.path.basename(dst))

    if not keep_raw:
        shutil.rmtree(rawdir, ignore_errors=True)
    else:
        os.rmdir(rawdir) if not os.listdir(rawdir) else None

    try:
        os.remove(ps1)
    except OSError:
        pass

    print("渲染完成：%d 页 -> %s" % (len(made), outdir))
    if made:
        print("  首页: %s   末页: %s" % (made[0], made[-1]))
    print("  日志: %s" % log)
    return 0


def main():
    ap = argparse.ArgumentParser(description="pptx 逐页渲染 PNG（PowerPoint COM）")
    ap.add_argument("pptx", help="课件 pptx 路径")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--prefix", default="p", help="文件前缀，默认 p -> p001.png")
    ap.add_argument("--keep-raw", action="store_true", help="保留 PowerPoint 原始导出目录")
    a = ap.parse_args()
    sys.exit(run(a.pptx, a.out, a.prefix, a.keep_raw))


if __name__ == "__main__":
    main()
