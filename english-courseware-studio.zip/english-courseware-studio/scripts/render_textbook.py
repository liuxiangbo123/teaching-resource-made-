# -*- coding: utf-8 -*-
"""
教材页面渲染工具 —— 供「英语课件工坊」读取扫描件版教材使用。

扫描件教材（无文字层）无法直接抽取文字，但把页面渲染成图片后，
可由具备视觉能力的模型逐页准确读取内容（实测 72 DPI 亦可读）。

用法：
  1) 探测模式：先渲染少量页面，确认文件页码与教材印刷页码的偏移量
     python render_textbook.py "<教材.pdf>" --probe 9 10 12 --out "<输出目录>"

  2) 按文件页码渲染
     python render_textbook.py "<教材.pdf>" --pages 9-24 --out "<输出目录>" --dpi 200

  3) 按教材印刷页码渲染（需已知偏移量 offset，offset = 文件页 - 印刷页）
     python render_textbook.py "<教材.pdf>" --book-pages 4-19 --offset 5 --out "<输出目录>"

  4) 仅检测类型（不渲染）
     python render_textbook.py "<教材.pdf>" --check

输出：pNNN.png（文件页码三位补零），并打印偏移量核对提示。
"""
import argparse
import os
import sys

try:
    import pymupdf as fitz
except ImportError:
    try:
        import fitz
    except ImportError:
        sys.exit("需要 PyMuPDF：pip install pymupdf")


def check_textlayer(doc):
    """前 10 页文字总字符数：>=200 视为文字层 PDF，否则为扫描件"""
    n = min(10, doc.page_count)
    tot = sum(len((doc[i].get_text() or "").strip()) for i in range(n))
    return tot


def probe_offset(doc, pages, dpi):
    """渲染指定文件页，用于人工/模型确认偏移量"""
    results = []
    for pno in pages:
        if not (1 <= pno <= doc.page_count):
            print("  p%-4d 超出范围（共 %d 页）" % (pno, doc.page_count))
            continue
        pg = doc[pno - 1]
        pix = pg.get_pixmap(dpi=dpi)
        results.append((pno, pix))
    return results


def parse_range(s):
    """支持 '9-24' 或 '9,10,12'"""
    s = s.strip()
    if "-" in s and "," not in s:
        a, b = s.split("-")
        return list(range(int(a), int(b) + 1))
    return [int(x) for x in s.split(",") if x.strip()]


def main():
    ap = argparse.ArgumentParser(description="教材页面渲染工具")
    ap.add_argument("pdf", help="教材 PDF 路径")
    ap.add_argument("--pages", help="文件页码范围，如 9-24")
    ap.add_argument("--book-pages", help="教材印刷页码范围，如 4-19，需配 --offset")
    ap.add_argument("--offset", type=int, help="偏移量 = 文件页 - 印刷页")
    ap.add_argument("--probe", nargs="+", type=int, help="探测模式：渲染这些文件页")
    ap.add_argument("--out", default="./教材渲染", help="输出目录")
    ap.add_argument("--dpi", type=int, default=200, help="渲染 DPI，默认 200")
    ap.add_argument("--check", action="store_true", help="仅检测是否为扫描件")
    args = ap.parse_args()

    if not os.path.exists(args.pdf):
        sys.exit("找不到文件：%s" % args.pdf)

    doc = fitz.open(args.pdf)
    name = os.path.basename(args.pdf)

    # ---- 类型检测 ----
    tot = check_textlayer(doc)
    print("=" * 66)
    print("文件：%s" % name)
    print("页数：%d" % doc.page_count)
    if tot >= 200:
        print("类型：文字层 PDF（前10页 %d 字符）→ 可直接抽取文字，无需渲染" % tot)
    else:
        print("类型：扫描件（前10页 %d 字符）→ 无文字层，需渲染成图片后视觉读取" % tot)
    print("=" * 66)

    if args.check:
        doc.close()
        return

    os.makedirs(args.out, exist_ok=True)

    # ---- 探测模式 ----
    if args.probe:
        print("\n[探测模式] 渲染文件页 %s，请查看右下角印刷页码，"
              "偏移量 = 文件页 - 印刷页\n" % ", ".join(str(p) for p in args.probe))
        for pno, pix in probe_offset(doc, args.probe, args.dpi):
            fp = os.path.join(args.out, "p%03d.png" % pno)
            pix.save(fp)
            print("  文件 p%-4d -> %s  (%.0f KB)"
                  % (pno, os.path.basename(fp), os.path.getsize(fp) / 1024))
        doc.close()
        print("\n提示：拿到印刷页码后，用 --book-pages X-Y --offset N 按印刷页码渲染。")
        return

    # ---- 渲染模式 ----
    if args.book_pages:
        if args.offset is None:
            doc.close()
            sys.exit("使用 --book-pages 时必须提供 --offset（偏移量 = 文件页 - 印刷页）")
        b = parse_range(args.book_pages)
        pages = [p + args.offset for p in b]
        print("\n[按印刷页码] 印刷页 %s → 文件页 %s（offset=%d）"
              % (args.book_pages, "%d-%d" % (pages[0], pages[-1]), args.offset))
    elif args.pages:
        pages = parse_range(args.pages)
        print("\n[按文件页码] 渲染 %d 页" % len(pages))
    else:
        doc.close()
        sys.exit("请指定 --pages / --book-pages / --probe / --check 之一")

    n_ok = 0
    for pno in pages:
        if not (1 <= pno <= doc.page_count):
            print("  跳过 p%d：超出范围" % pno)
            continue
        pix = doc[pno - 1].get_pixmap(dpi=args.dpi)
        fp = os.path.join(args.out, "p%03d.png" % pno)
        pix.save(fp)
        n_ok += 1
    doc.close()

    print("已渲染 %d 页 → %s" % (n_ok, os.path.abspath(args.out)))
    print("\n下一步：逐页读取图片内容，按教材印刷页码记账，"
          "所有教材原文务必逐字核对，不得凭印象改写。")


if __name__ == "__main__":
    main()
