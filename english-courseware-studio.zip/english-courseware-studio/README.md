# 英语课件工坊（Team 型专家团）

按单元批量产出初中／高中英语教学课件，交付真实 `.pptx`（动画写入 `p:timing`，PowerPoint/WPS 动画窗格可见）。

## 团队构成

| Agent ID | 花名 | 职责 |
|---|---|---|
| `english-courseware-studio-team-lead` | 谭有度 | 课件总导演：学段判定、拆任务、控节奏、汇总、裁定争议 |
| `lesson-designer` | 路子明 | 教学思路设计师：元框架抽取、逐页脚本、教材页码对齐 |
| `layout-animator` | 董方寸 | 版式动画师：slidep 出 .pptx、动画窗格、逐页渲染、素材台账 |
| `qc-inspector` | 查秋毫 | 质检把关人：四项检测、英语专项检测、跨单元一致性 |

## 用法

1. 在专家页打开「英语课件工坊」
2. 上传参考课件与教材
3. 先要骨架 → 确认 → 出第 1 单元样张 → 确认版式基准 → 按批铺开（每批 ≤5 单元）

## 红线

- 只借参考课件的**形制**（讲解思路、环节编排、提问方式），**不借内容**
- 严禁照搬原文、例句、习题、图片、排版样式
- 教材或参考课件查不到依据的内容，一律标【假设：……，请核对】
- 音频／视频由用户提供，默认随包交付不嵌入，页面写教师播放提示；不得伪造路径或声称已嵌入

## 教材读取工具

`scripts/render_textbook.py`：教材类型检测 + 页面渲染。

教材分两类，**扫描件不再是障碍，只是走另一条读取路径**：

| 类型 | 特征 | 读取方式 |
|---|---|---|
| 文字层 PDF | 能在阅读器里选中并复制英文单词 | 直接抽取文字，最快最准 |
| 扫描件 | 页面是图片，选中不了 | 渲染成图片后**逐页看图读取**（实测 72 DPI 也能读准） |

```bash
# 检测是哪种
python scripts/render_textbook.py "<教材.pdf>" --check

# 扫描件：先探测文件页与印刷页的偏移量（看页脚页码）
python scripts/render_textbook.py "<教材.pdf>" --probe 9 10 12 --out "<目录>"

# 按教材印刷页码渲染整个单元（偏移量 = 文件页 - 印刷页）
python scripts/render_textbook.py "<教材.pdf>" --book-pages 4-19 --offset 4 --out "<目录>" --dpi 200
```

依赖 `pymupdf`。渲染后逐页读取，**按教材印刷页码记账**；
音标、注释小字、密集表格须单列成表交用户核对，读不清一律标【原图不清，请核对】，不许猜。

## 自动质检器

`skills/teaching-material-rules/scripts/qa_pptx.py`：交付前必跑，覆盖 C1–C12（越界/重叠/遮挡/溢出/对比度/图拉伸/图不清/字号过小/空动画组/动画孤儿/路径终点/字号不齐）。

```bash
python qa_pptx.py <file.pptx> [--brief] [--json report.json]
```

依赖 `python-pptx`。结果需结合渲染 PNG 复核（C5、C3 存在已知误报）。

## 技能副本说明（重要）

本包 `skills/` 下两个技能是**副本**，存在同步问题，改动时注意：

| 技能 | 真源位置 | 说明 |
|---|---|---|
| `teaching-material-rules` | `my-experts/plugins/teaching-material-expert/skills/teaching-material-rules` | 与「备课搭子」专家共用。改规则后需同步两处 |
| `slidep-teaching-deck` | `~/.workbuddy/skills/slidep-teaching-deck`（用户级技能） | 生成 .pptx 的技术底座 |

复制进包是为了让专家包可分发出去（plugin 的 `skills` 字段只认包内相对路径）。

## 教材来源红线

教材版权归出版社（外研版＝外语教学与研究出版社）。**抓取、下载、转存教材 PDF 或教材原文，
性质等同于"照搬原文"**，与禁止照搬参考课件是同一条红线。

- ❌ 不从网络搜索 / 下载 / 抓取 / 转存任何教材 PDF 或教材原文
- ❌ 不向用户提供"高清版教材"、盗版下载源、网盘资源
- ✅ 教材只能由用户提供，仅用于本次生产，不随包外传

用户索要高清版时：说明版权原因 + 给官方渠道（国家中小学智慧教育平台，仅供在线浏览），
**然后转向"手上这版其实能用"的技术路径**（见上一节），不要停在"给不了"。

## 开工前检查清单

| # | 检查项 | 命令 / 标准 |
|---|---|---|
| 1 | 教材类型 | `render_textbook.py "<教材.pdf>" --check` |
| 2 | 扫描件的偏移量 | `--probe 9 10 12` 看页脚印刷页码，**每册不同，必测** |
| 3 | 规则库副本是否过期 | `diff -rq` 对比 `teaching-material-expert/skills/teaching-material-rules` |
| 4 | slidep 是否安装 | 未装不得声称已生成 pptx |
| 5 | python-pptx 是否可用 | 质检器依赖，未装不许跳过或谎报 |

已实测偏移量：八上2026秋新版 **+5** ／ 八下2024版 **+4** ／ 九上2026秋定稿 **+5** ／ 九下 **+4**。

## 前置依赖

生产前需确认 `@tencent/slidep` 已安装（node workspace 内 `npm install @tencent/slidep`）。
未安装时不得声称"已生成 pptx"。

| 依赖 | 状态 | 用途 |
|---|---|---|
| `pymupdf` 1.28.2 | 已装（`~/.workbuddy/binaries/python/envs/default`） | 教材渲染读取 |
| `python-pptx` 1.0.2 | 已装（同 venv） | 自动质检器 |
| `Pillow` 12.3.0 | 已装（同 venv） | 图片处理 |
| `@tencent/slidep` | **未安装** | 出 pptx 的硬阻塞 |
| PowerPoint | 已装，可导出逐页 PNG | 渲染目检 |
| WPS / LibreOffice | 未装 | WPS 兼容性需人工抽检 |

用 `import pymupdf`，`fitz` 别名已废弃会告警。

## 环境提示

本机已装 PowerPoint（可走自动化导出逐页 PNG 用于渲染目检）；未装 WPS 与 LibreOffice，
WPS 兼容性需人工抽检。质检清单中"未实际验证"的项必须显式声明，不得写成通过。

## 作者

刘象博 <15062273656@163.com>
