# R1c slidep 从零生成生产线（.pptx 文件级）

> 适用场景：**不是改造范本 pptx**（那走 R1b），而是用 slidep/SlideDSL 从零构建课件 .pptx（本系列"仿骨架 + 换教材内容"的批量生产即此线）。与 R1b 互补：R1b 管改造范本的陷阱，本条管从零生成的**生产线次序、布局规则与动画工序**。交付前仍须并行叠加 R10/R12；跨份批量另叠加 R14。

## 一、生产线（7 步，不许跳步）

1. **教材内容逐字提取**：渲染教材 PDF 对应页为 PNG 并逐页目检（含页脚页码确认）。⚠️ **页码映射不恒定**：同一本教材不同单元的 `PDF index = 页脚页码 + 偏移` 可能不同（U1 是 +5，U2 起变 +4）——禁止套公式，逐页渲染页脚确认后再提取。
2. **写 build 脚本**：复用既有 helper 体系（`T/ANI/BX/IMG/header/slide/card`），把教材内容做成数据结构驱动生成（改数据不改骨架）。每页输出一个 `.slide` 文件。
3. **构建 deck**：`slidep create <out.pptx>` → 对每页 `upsert-dsl --dsl-file <i.slide>`。⚠️ **upsert-dsl 是追加模式**：对同一页重复 upsert 不会替换而是叠加，**改任何一页都必须删掉重建整个 deck 全量重插**。
4. **动画逐击后处理**：`python scripts/fix_anim_clicks.py <in.pptx> <out.pptx>`（见第二节）。
5. **渲染逐页目检**：全部页渲染成 PNG 逐页看（渲染图是唯一能看见成品真实排版的手段，静态结构检查替代不了）。修过的页必须复查。
6. **qa 质检**：`python scripts/qa_pptx.py <file.pptx>`，FATAL 必须清零才交付。
7. **COM 双指标验证 + 交付**：`python scripts/com_verify.py <file.pptx>`——每页动画**数量** + 首效果 **TriggerType==1（单击）**。只验数量不验触发方式，会把"全页同组同步触发"误判通过（曾因此被用户截图纠偏）。

## 二、动画工序：fix_anim_clicks.py（逐击重写）

slidep 的已知缺陷：所有 `<Animation>` 被写进**同一个** `delay="indefinite"` 点击组且 nodeType 全为 `withEffect` → 放映时单击一下整页同时出现、动画窗格序号全 0。修复＝后处理器重建 timing：

- 提取每页 innermost entr 效果（set + animEffect），按 PowerPoint 标准骨架重建：**每效果一个独立 `delay="indefinite"` 点击组 + `nodeType="clickEffect"`** + prevCondLst/nextCondLst + bldLst。
- ⚠️ **id 重编号正则陷阱**：`re.sub(r'id="\d+"')` 会误匹配 `spid="15"` 的子串把动画目标改坏（PowerPoint 丢弃效果、COM count 骤降）。必须用负向断言 `(?<![A-Za-z])id="\d+"`。
- ⚠️ Bash 直接写 powershell 会被安全钩子拦截——COM 操作必须封装进 .py（subprocess → powershell.exe -File）。

设计铁律：**答案/揭示内容全部殿后逐击出现**（fadeIn + click），与 R1b 陷阱 18 一致——答案绝不能静态暴露（qa C13 把关），也绝不能画进图片。

## 三、SlideDSL 布局规则（实测沉淀）

**全局缩放**：
- `SCALE=1.3`（字号）、`SCALES=1.22`（容器/间距/图片）；**仅 w<1200 的值参与缩放**——`width:1180` 会被放大到 1440 溢出页面（内容区仅约 1232）。
- **bXX 显式宽度 + 白卡片 pad 会双重溢出**：正确做法是 bXX 不设宽度，让其自然撑满卡片。

**ANI 动画包裹**：
- **ANI 单子元素铁律**：一个 ANI 只包一个子元素；要包多个就先合成一个 BX。
- **ANI 包多行文本的 ghost 重叠坑**：面板 `flex=1` 时高度被低估 → 相邻段落渲染重叠。修法：去掉面板 flex=1；row 内多段 T 混排一换行就重叠，**长句必须拆单行**。
- 8 段课文全文一页放下参考参数：¶ 字号 13、lh 1.38、段 gap 5（再大 A2 问答就被挤出页底）。

**文本与容器**：
- **T 的前导空格被渲染裁掉** → 相邻两个 T 粘连成 "thinkfor"。用 `'· '` 等可见前缀分隔，或拆成独立元素。
- **BX 位置参数陷阱**：把 T 的参数（size/color 等）按位置传给 BX 会落到 pad 等参数上，症状隐蔽（报错或样式错乱）。写嵌套表达式时逐层核对括号配对。
- **深色插画封面**：标题文字必须包白色半透明卡（`bg='rgba(255,255,255,0.88)' + br + pad`），否则彩字压深底不可读。
- **留白页垂直居中**：外层行/列容器加 `justify='center'`。
- **三列短语表过窄** → 中英文粘连溢出。改两列 + 行内前缀空格 + `justify='center'`；行高按内容给足（rowh≥48）。

**插画素材**：
- ImageGen 出图右下有「AI生成」水印 → PIL 裁剪（crop 至 97%×93%）去除后再入包；封面图裁 16:9。
- 图内文字遵守 R1b 陷阱 16 的屏显字号换算。

## 四、本条自检

- 教材每页页码偏移是否逐页核实（未套公式）？课文/练习是否逐字对齐教材？
- deck 是否全量重建（而非对旧文件单页 upsert）？
- fix_anim_clicks 后 COM 双指标是否全过（数量 + 首效果 TriggerType=1）？
- 渲染图是否逐页目检、修过的页是否复查？qa 是否 FATAL=0？
- 答案是否全部殿后逐击、无一静态暴露？插画水印是否已裁？
