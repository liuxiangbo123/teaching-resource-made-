# -*- coding: utf-8 -*-
"""
PPTX 交付质检器 —— R12 验收清单的自动化实现

用法:
    python qa_pptx.py <file.pptx> [--brief] [--json report.json]

检查项（对应 R12 六维度中可计算的部分）:
  C1 越界       形状超出画布
  C2 重叠       文本框之间几何重叠（有意叠加除外）
  C3 压图文字   文本框覆盖图片且该区域有内容 -> 遮挡原文
  C4 溢出       文字估算高度 > 框高（含行数估算）
  C5 对比度     浅色字 + 无深色底 = 看不见
  C6 图拉伸     位图比例 vs 显示框比例不符
  C7 图不清     图片有效 DPI 过低
  C8 字号过小   正文字号 < 10pt
  C9 空动画组   timing 中无有效目标的死点击组
  C10 动画孤儿  动画目标形状不存在
  C11 路径终点  路径动画终点落在图片区内 -> 可能被图层遮住/错位
  C12 字号不齐  同一画布内相近文本块字号差异过大 -> 主次失衡
  C13 静态答案  疑似答案/逐步揭示的文本(Key: / 答案 / 参考答案)未出现在动画序列中
                -> 放映时直接暴露, 失去"先想后看"的问题设计作用

输出分级: [FATAL] 必须修  [WARN] 应核查  [INFO] 供参考

已知局限（重要）:
  - C5 只看幻灯片形状树里的填充。若深色衬底来自 slide master / layout 背景，
    会产生误报 -> **必须结合渲染图复核**（参见 R12 第七节验证流程）。
  - C3 用"行起伏 sd"区分纯色深底与含文字的图；装饰纹理类底图仍可能误报。
  - 工具的价值是"把抽查变成全查"，不能替代最终的人眼确认。
"""
import sys, os, json, argparse, re
from pptx import Presentation
from pptx.util import Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE

A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
P = '{http://schemas.openxmlformats.org/presentationml/2006/main}'
NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}

try:
    from PIL import Image
    import io
    HAS_PIL = True
except Exception:
    HAS_PIL = False


# ---------- 几何工具 ----------

def _grp_xf(sh):
    """返回 (off, ext, chOff, chExt)，单位 EMU；非组或缺失时为 None 项"""
    el = sh._element
    # 组形状的 xfrm 在 p:grpSpPr/a:xfrm；普通形状在 p:spPr/a:xfrm
    xf = el.find(A + 'spPr/' + A + 'xfrm')
    if xf is None:
        xf = el.find('.//' + A + 'xfrm')   # 兜底: 覆盖 p:grpSpPr/a:xfrm 等路径
    if xf is None:
        return None
    def num(tag):
        e = xf.find(A + tag)
        if e is None: return None
        try:
            # off 用 x/y，ext/chExt 用 cx/cy
            if tag in ('ext', 'chExt'):
                return int(e.get('cx')), int(e.get('cy'))
            return int(e.get('x')), int(e.get('y'))
        except Exception: return None
    return num('off'), num('ext'), num('chOff'), num('chExt')


def _grp_map(sh):
    """group 的子坐标缩放: child -> abs = off + (c - chOff) * (ext/chExt)，返回 (sx, sy)"""
    xf = _grp_xf(sh)
    if xf is None:
        return 1.0, 1.0
    off, ext, choff, chext = xf
    sx = sy = 1.0
    if chext and ext and chext[0] and chext[1]:
        sx = ext[0] / chext[0]; sy = ext[1] / chext[1]
    return sx, sy


def iter_shapes(shapes, parent=None, depth=0):
    """递归产出 (shape, left_in, top_in, w_in, h_in, depth)"""
    for sh in shapes:
        try:
            l = Emu(sh.left).inches; t = Emu(sh.top).inches
            w = Emu(sh.width).inches; h = Emu(sh.height).inches
        except Exception:
            continue
        if parent is not None and depth > 0:
            sx, sy = _grp_map(parent)
            l = parent_l + (l - parent_l) * sx
            t = parent_t + (t - parent_t) * sy
            w *= sx; h *= sy
        yield sh, l, t, w, h, depth
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            try:
                for x in iter_shapes(sh.shapes, sh, depth + 1):
                    yield x
            except Exception:
                pass
        parent_l, parent_t = l, t


def abs_rect(shapes):
    """带 group 变换的绝对矩形列表（正确处理 chOff：child坐标先减 chOff 再缩放）"""
    out = []
    stack = [(list(shapes), None, 0.0, 0.0, 1.0, 1.0)]
    while stack:
        items, parent, pl, pt, sx, sy = stack.pop()
        for sh in items:
            try:
                cl = Emu(sh.left).inches
                ct = Emu(sh.top).inches
                w = Emu(sh.width).inches
                h = Emu(sh.height).inches
            except Exception:
                continue
            if parent is not None:
                xfi = _grp_xf(parent)
                if xfi is not None and xfi[2] and xfi[3]:
                    cox, coy = xfi[2]          # chOff (EMU)
                    l = pl + (cl - Emu(cox).inches) * sx
                    t = pt + (ct - Emu(coy).inches) * sy
                else:
                    l = pl + cl * sx
                    t = pt + ct * sy
                w *= sx; h *= sy
            else:
                l, t = cl, ct
            out.append((sh, l, t, w, h))
            if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
                gx, gy = _grp_map(sh)
                try:
                    stack.append((list(sh.shapes), sh, l, t, sx * gx, sy * gy))
                except Exception:
                    pass
    return out


def run_color(r):
    try:
        if r.font.color is not None and r.font.color.type is not None:
            return str(r.font.color.rgb)
    except Exception:
        pass
    return None


def solid_fill(el):
    spPr = el.find('.//' + A + 'spPr')
    if spPr is None: return None
    sf = spPr.find(A + 'solidFill')
    if sf is None: return None
    c = sf.find('.//' + A + 'srgbClr')
    return c.get('val') if c is not None else 'scheme'


def is_light(hexstr):
    if not hexstr: return False
    try:
        r, g, b = int(hexstr[0:2], 16), int(hexstr[2:4], 16), int(hexstr[4:6], 16)
        return (0.299 * r + 0.587 * g + 0.114 * b) > 175
    except Exception:
        return False


def est_text_h(tf, w_in):
    """估算文本所需英寸高度"""
    total = 0.0
    for p in tf.paragraphs:
        txt = ''.join(r.text for r in p.runs)
        sz = max([r.font.size.pt for r in p.runs if r.font.size] or [18])
        wid = 0.0
        for ch in txt:
            wid += (sz if ord(ch) > 0x2E80 else sz * 0.55) / 72.0
        lines = max(1, int(wid / max(w_in - 0.1, 0.2)) + 1)
        total += lines * sz * 1.32 / 72.0
    return total


# ---------- 主检查 ----------

def check(path, brief=False):
    prs = Presentation(path)
    SW, SH = Emu(prs.slide_width).inches, Emu(prs.slide_height).inches
    issues = []

    def add(sno, code, level, msg):
        issues.append({'slide': sno, 'code': code, 'level': level, 'msg': msg})

    for sno, slide in enumerate(prs.slides, 1):
        rects = abs_rect(slide.shapes)
        textboxes, pictures = [], []

        # 先收集图片：C5 要靠它判断"是不是有一块深色底图托着"
        for sh, l, t, w, h in rects:
            if HAS_PIL and sh.shape_type == MSO_SHAPE_TYPE.PICTURE:
                try:
                    pictures.append((sh, l, t, w, h, Image.open(io.BytesIO(sh.image.blob))))
                except Exception:
                    pass

        for sh, l, t, w, h in rects:
            kind = sh.shape_type
            # C1 越界（零尺寸隐藏形状豁免; 范本出血图属设计语言, 交渲染目检裁决）
            if w < 0.01 and h < 0.01:
                continue
            if l < -0.05 or t < -0.05 or l + w > SW + 0.05 or t + h > SH + 0.05:
                nm = sh.text_frame.text[:18].replace('\n', ' ') if sh.has_text_frame else str(kind)
                add(sno, 'C1', 'WARN', f'越界 id={sh.shape_id} L={l:.2f} T={t:.2f} W={w:.2f} H={h:.2f} | {nm}')
            if not sh.has_text_frame:
                continue
            tf = sh.text_frame
            txt = tf.text.strip()
            if not txt: continue
            textboxes.append((sh, l, t, w, h, txt))

            # C4 溢出（word_wrap=False 的单行覆盖框不适用多行估算, 豁免）
            try:
                if not tf.word_wrap:
                    need = None
                else:
                    need = est_text_h(tf, w)
                if need is not None and need > h + 0.06:
                    add(sno, 'C4', 'WARN',
                        f'文字溢出 id={sh.shape_id} 框高={h:.2f} 需≈{need:.2f} | {txt[:26]}')
            except Exception:
                pass

            # C5 对比度
            fill = solid_fill(sh._element)
            colors = set()
            for p in tf.paragraphs:
                for r in p.runs:
                    c = run_color(r)
                    if c: colors.add(c)
            if any(is_light(c) for c in colors) and (fill is None or is_light(fill)):
                # 关键：底层可能另有无文字的深色形状作衬底（这才是"看得见"的真实机制）
                covered = False
                for other, ol, ot, ow, oh in rects:
                    if other is sh: continue
                    try:
                        if other.has_text_frame and other.text_frame.text.strip(): continue
                    except Exception: continue
                    of_ = solid_fill(other._element)
                    if of_ and not is_light(of_):
                        ox_ = max(0, min(l + w, ol + ow) - max(l, ol))
                        oy_ = max(0, min(t + h, ot + oh) - max(t, ot))
                        if ox_ > w * 0.8 and oy_ > h * 0.8:
                            covered = True; break
                if not covered and HAS_PIL:
                    # 再看是否压在一块深色底图/背景面板上
                    for pic, pl2, pt2, pw2, ph2, im2 in pictures:
                        ox2_ = max(0, min(l + w, pl2 + pw2) - max(l, pl2))
                        oy2_ = max(0, min(t + h, pt2 + ph2) - max(t, pt2))
                        if ox2_ < w * 0.5 or oy2_ < h * 0.5:
                            continue
                        g2 = im2.convert('L'); q2 = g2.load()
                        sx1 = int((max(l, pl2) - pl2) / pw2 * im2.width)
                        sx2 = int((min(l + w, pl2 + pw2) - pl2) / pw2 * im2.width)
                        sy1 = int((max(t, pt2) - pt2) / ph2 * im2.height)
                        sy2 = int((min(t + h, pt2 + ph2) - pt2) / ph2 * im2.height)
                        sx2 = max(sx2, sx1 + 1); sy2 = max(sy2, sy1 + 1)
                        tt = dd = 0
                        for yy in range(sy1, min(sy2, im2.height), 4):
                            for xx in range(sx1, min(sx2, im2.width), 4):
                                tt += 1
                                if q2[xx, yy] < 150: dd += 1
                        if tt and dd / tt > 0.5:
                            covered = True; break
                if not covered:
                    add(sno, 'C5', 'FATAL',
                        f'浅色字无深底 id={sh.shape_id} color={sorted(colors)} fill={fill} | {txt[:26]}')

            # C8 字号过小
            sizes = [r.font.size.pt for p in tf.paragraphs for r in p.runs if r.font.size]
            if sizes and max(sizes) < 10 and len(txt) > 8:
                add(sno, 'C8', 'INFO', f'字号过小 id={sh.shape_id} {max(sizes)}pt | {txt[:26]}')

        # C2 文本框两两重叠（答案覆盖框豁免: word_wrap=False 且低矮的框是"先遮后显"覆盖设计）
        def is_overlay(sh_, h_):
            try:
                return h_ < 0.6 and sh_.text_frame.word_wrap is False
            except Exception:
                return False
        for i in range(len(textboxes)):
            for j in range(i + 1, len(textboxes)):
                a, b = textboxes[i], textboxes[j]
                if is_overlay(a[0], a[4]) or is_overlay(b[0], b[4]):
                    continue
                ox = max(0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
                oy = max(0, min(a[2] + a[4], b[2] + b[4]) - max(a[2], b[2]))
                if ox > 0.08 and oy > 0.08:
                    add(sno, 'C2', 'WARN',
                        f'文本重叠 id={a[0].shape_id} vs id={b[0].shape_id} {ox:.2f}x{oy:.2f}in '
                        f'| "{a[5][:16]}" / "{b[5][:16]}"')

        # C3 / C6 / C7 图片相关
        for pic, pl, pt, pw, ph, im in pictures:
            # C6 拉伸（整页背景图豁免: 纹理/图案类背景拉伸无视觉影响, 范本亦如此）
            try:
                if not (pw >= SW * 0.95 and ph >= SH * 0.95):
                    br = im.width / im.height
                    fr = pw / ph
                    if abs(br - fr) / max(br, 1e-6) > 0.04:
                        add(sno, 'C6', 'WARN',
                            f'图片可能被拉伸 id={pic.shape_id} 位图比={br:.3f} 框比={fr:.3f}')
            except Exception:
                pass
            # C7 清晰度
            if im.width and pw > 0:
                dpi = im.width / pw
                if dpi < 96:
                    add(sno, 'C7', 'INFO', f'图片清晰度低 id={pic.shape_id} ≈{dpi:.0f}dpi')

            # C3 文本框压住图片内容（整页背景图豁免：≥85%版面的图片视为背景）
            if pw * ph >= 0.85 * SW * SH:
                continue
            gray = im.convert('L'); gpx = gray.load()
            for sh, l, t, w, h, txt in textboxes:
                ox1 = max(l, pl); oy1 = max(t, pt)
                ox2 = min(l + w, pl + pw); oy2 = min(t + h, pt + ph)
                if ox2 - ox1 < 0.05 or oy2 - oy1 < 0.05:
                    continue
                # 单行覆盖框豁免：显式 word_wrap=False 且 h<0.6 的窄条文本框
                # 是答案交互覆盖框（先遮后显设计），盖住空格是刻意的，不算遮挡
                try:
                    if sh.text_frame.word_wrap is False and h < 0.6:
                        continue
                except Exception:
                    pass
                bx1 = int((ox1 - pl) / pw * im.width); bx2 = int((ox2 - pl) / pw * im.width)
                by1 = int((oy1 - pt) / ph * im.height); by2 = int((oy2 - pt) / ph * im.height)
                bx2 = max(bx2, bx1 + 1); by2 = max(by2, by1 + 1)
                tot = dark = 0
                for yy in range(by1, min(by2, im.height), 3):
                    for xx in range(bx1, min(bx2, im.width), 3):
                        tot += 1
                        if gpx[xx, yy] < 150: dark += 1
                if tot and dark / tot > 0.06:
                    ratio = dark / tot
                    # 行剖面：纯色块底每行都极暗且均匀；含文字的图有明显的行/间隙起伏
                    rows = []
                    for yy in range(by1, min(by2, im.height), 3):
                        cnt = tt = 0
                        for xx in range(bx1, min(bx2, im.width), 3):
                            tt += 1
                            if gpx[xx, yy] < 150: cnt += 1
                        if tt: rows.append(cnt / tt)
                    if rows:
                        mean = sum(rows) / len(rows)
                        var = sum((v - mean) ** 2 for v in rows) / len(rows)
                        sd = var ** 0.5
                    else:
                        mean, sd = 0, 0
                    if mean > 0.85:
                        # 整片深色 = 设计好的深底容器，文字放上去是刻意的，不算遮挡
                        pass
                    elif sd > 0.04:
                        add(sno, 'C3', 'FATAL',
                            f'文本框压住图片文字 id={sh.shape_id} 暗像素{ratio*100:.0f}% '
                            f'行起伏sd={sd:.2f} (图片id={pic.shape_id}) | {txt[:24]}')
                    else:
                        add(sno, 'C3', 'INFO',
                            f'文本框压住图片区 id={sh.shape_id} 暗像素{ratio*100:.0f}% '
                            f'均匀底纹sd={sd:.2f} (图片id={pic.shape_id}) | {txt[:24]}')

        # C9 / C10 / C11 动画
        try:
            from lxml import etree
            root = etree.fromstring(slide.part.blob)
        except Exception:
            root = None
        if root is not None:
            exist_ids = {sh.shape_id for sh in slide.shapes}
            for sh, *_ in rects:
                pass
            all_ids = set()
            for sh, *_x in abs_rect(slide.shapes):
                try: all_ids.add(sh.shape_id)
                except Exception: pass
            ms = root.find('.//p:timing//p:cTn[@nodeType="mainSeq"]', NS)
            if ms is not None:
                ch = ms.find('p:childTnLst', NS)
                order = []
                for par in ch.findall('p:par', NS):
                    spids = set()
                    for e in par.findall('.//p:spTgt', NS):
                        sid = e.get('spid')
                        if sid: spids.add(int(sid))
                    if not spids:
                        k = len(order) + 1
                        add(sno, 'C9', 'WARN', f'空动画组（放映时无效点击）第{k}组')
                    else:
                        for sid in spids:
                            order.append(sid)
                            if sid not in all_ids:
                                add(sno, 'C10', 'FATAL', f'动画目标不存在 spid={sid}')
                    # C11 路径终点
                    for am in par.findall('.//p:animMotion', NS):
                        pth = am.get('path') or ''
                        pts = pth.replace('M', '').replace('L', '').split()
                        if len(pts) >= 2:
                            try:
                                dx, dy = float(pts[-2]), float(pts[-1])
                            except Exception:
                                continue
                            for tgt in (x for x in spids):
                                for sh, l, t, w, h in [(x[0], x[1], x[2], x[3], x[4])
                                                       for x in abs_rect(slide.shapes)
                                                       if x[0].shape_id == tgt]:
                                    ex = l + dx * SW; ey = t + dy * SH
                                    if ex < 0 or ey < 0 or ex + w > SW + 0.05 or ey + h > SH + 0.05:
                                        add(sno, 'C11', 'FATAL',
                                            f'路径终点出界 id={tgt} -> ({ex:.2f},{ey:.2f})')
                                    for pic, pl, pt2, pw, ph, _im in pictures:
                                        ov = (max(0, min(ex + w, pl + pw) - max(ex, pl)) *
                                              max(0, min(ey + h, pt2 + ph) - max(ey, pt2)))
                                        if ov > 0.2:
                                            add(sno, 'C11', 'WARN',
                                                f'路径动画终点落在图片区 id={tgt} '
                                                f'重叠{ov:.2f}in² (图id={pic.shape_id}) 注意图层顺序')

        # C13 静态暴露的答案：疑似"学生先想、教师后出示"的文本必须出现在动画序列里
        # 两级识别: ①强信号=文本含答案关键词(Key:/Answer:/参考答案)  ②结构信号=红色·无填充·无边框·压在图上(答案覆盖框)
        ans_re = re.compile(r'^\s*(key|keys|answer|answers|ans|a)\s*[:：]|^\s*(参考答案|答案)\s*[:：]?',
                            re.I)
        animated_ids = set()
        if root is not None:
            ms2 = root.find('.//p:timing//p:cTn[@nodeType="mainSeq"]', NS)
            if ms2 is not None:
                ch2 = ms2.find('p:childTnLst', NS)
                for par2 in (ch2.findall('p:par', NS) if ch2 is not None else []):
                    for e in par2.findall('.//p:spTgt', NS):
                        if e.get('spid'):
                            animated_ids.add(int(e.get('spid')))
        # 画了填空线的题干框几何范围（信号②用：答案通常就覆盖在它的 ____ 上）
        blank_boxes = [(t[1], t[2], t[3], t[4]) for t in textboxes if '____' in (t[5] or '')]
        for sh, l, t, w, h, txt in textboxes:
            if sh.shape_id in animated_ids:
                continue
            hit = ans_re.match(txt or '')
            if hit:
                add(sno, 'C13', 'FATAL',
                    f'静态暴露的答案 id={sh.shape_id} 无单击动画 -> 放映时直接显示 "{txt[:28]}"')
                continue
            # 结构信号：红色 + 无纯色填充 + 无边框 + 完整压在某张图上 ⇒ 答案覆盖框
            # 注意：不能用"本页有 ____ 文本框"做前置条件——填空线常常画在图片里，
            #       页面上根本没有含下划线的文本框（本次真实案例就是这样漏判的）
            if not pictures or len(txt or '') > 40:
                continue
            try:
                no_line = sh.line.fill.type is None or int(sh.line.fill.type) == 5
            except Exception:
                no_line = True
            cols = [run_color(r) for p in sh.text_frame.paragraphs for r in p.runs]
            cols = [c for c in cols if c]
            red = bool(cols) and all(c[0:2].lower() in ('d2', 'c0', 'c5', 'b0', 'e0', 'ff', 'dc', 'cc', 'cb', 'ca', 'd5', 'd9') or
                                     (int(c[0:2], 16) > 150 and int(c[2:4], 16) < 100 and int(c[4:6], 16) < 100)
                                     for c in cols)
            if not (red and no_line and solid_fill(sh._element) is None):
                continue
            for pic, pl, pt2, pw, ph, _im in pictures:
                # 整页背景图豁免：压在背景上的红色通常是封面标题/章节标签(PART.01)，不是答案
                if pw * ph >= 0.85 * SW * SH:
                    continue
                inside = (l >= pl - 0.02 and t >= pt2 - 0.02 and
                          l + w <= pl + pw + 0.02 and t + h <= pt2 + ph + 0.02)
                if inside:
                    add(sno, 'C13', 'WARN',
                        f'疑似答案覆盖框未配动画 id={sh.shape_id}（红色+无填充+压在图上）'
                        f'-> 放映时答案静态暴露 "{txt[:24]}"')
                    break  # 同一形状可能被背景图与内容图同时命中, 只报一次
            # 结构信号②：本页若有画了填空线(____)的题干框，则该红色无框文本视为覆盖其上的答案
            for ql, qt, qw, qh in blank_boxes:
                ox = max(0, min(l + w, ql + qw) - max(l, ql))
                oy = max(0, min(t + h, qt + qh) - max(t, qt))
                if ox > 0 and (oy > 0 or abs(t - (qt + qh)) <= 0.35):
                    add(sno, 'C13', 'WARN',
                        f'疑似填空答案未配动画 id={sh.shape_id}（红色+无框+紧贴含 ____ 的题干）'
                        f'-> 放映时答案静态暴露 "{txt[:24]}"')
                    break

        # C12 字号失衡
        body = []
        for sh, l, t, w, h, txt in textboxes:
            sizes = [r.font.size.pt for p in sh.text_frame.paragraphs for r in p.runs if r.font.size]
            if sizes and len(txt) > 12 and max(sizes) >= 14:
                body.append((max(sizes), sh.shape_id, txt[:20]))
        if body:
            mx = max(body)[0]
            for sz, sid, txt in body:
                if sz <= mx / 3.0 and mx >= 24:
                    add(sno, 'C12', 'INFO', f'主次字号悬殊 id={sid} {sz}pt vs 最大{mx}pt | {txt}')

    return {'file': path, 'slides': len(prs.slides), 'issues': issues}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('file')
    ap.add_argument('--brief', action='store_true')
    ap.add_argument('--json', dest='jsonout')
    a = ap.parse_args()

    rep = check(a.file, a.brief)
    its = rep['issues']
    lv = {'FATAL': 0, 'WARN': 1, 'INFO': 2}
    its.sort(key=lambda x: (lv[x['level']], x['slide']))

    if not HAS_PIL:
        print('[提示] 未安装 Pillow，C3/C6/C7 图片类检查已跳过')

    print(f"=== PPTX 质检报告 ===")
    print(f"文件: {os.path.basename(rep['file'])}   页数: {rep['slides']}")
    cnt = {}
    for i in its: cnt[i['level']] = cnt.get(i['level'], 0) + 1
    print(f"致命 {cnt.get('FATAL',0)} / 警告 {cnt.get('WARN',0)} / 提示 {cnt.get('INFO',0)}")
    print()
    cur = None
    for i in its:
        if i['slide'] != cur:
            cur = i['slide']
            print(f"--- 第 {cur} 页 ---")
        print(f"  [{i['level']:5s}] {i['code']}  {i['msg']}")

    if a.jsonout:
        json.dump(rep, open(a.jsonout, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print(f"\nJSON -> {a.jsonout}")

    print("\n判定: " + ("不可交付，先修致命项" if cnt.get('FATAL') else
                        ("建议核查警告项后再交付" if cnt.get('WARN') else "通过")))


if __name__ == '__main__':
    main()
