# -*- coding: utf-8 -*-
"""把 slidep 生成的「单组 withEffect」timing XML 重写为 PowerPoint 标准逐击 clickEffect 结构。
用法: python fix_anim_clicks.py <in.pptx> <out.pptx>
"""
import re
import shutil
import sys
import zipfile

EFFECT_PAR = re.compile(
    r'<p:par><p:cTn id="\d+" presetID="\d+" presetClass="entr"[^>]*>.*?</p:par>', re.S)

CLICK_TPL = (
    '<p:par><p:cTn id="{a}" fill="hold"><p:stCondLst><p:cond delay="indefinite"/></p:stCondLst>'
    '<p:childTnLst><p:par><p:cTn id="{b}" fill="hold"><p:stCondLst><p:cond delay="0"/></p:stCondLst>'
    '<p:childTnLst><p:par><p:cTn id="{c}" presetID="10" presetClass="entr" presetSubtype="0" '
    'fill="hold" grpId="0" nodeType="clickEffect"><p:stCondLst><p:cond delay="0"/></p:stCondLst>'
    '<p:childTnLst>{inner}</p:childTnLst></p:cTn></p:par>'
    '</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>'
)

SEQ_SKELETON = (
    '<p:timing><p:tnLst><p:par>'
    '<p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot"><p:childTnLst>'
    '<p:seq concurrent="1" nextAc="seek"><p:cTn id="2" dur="indefinite" nodeType="mainSeq">'
    '<p:childTnLst>{groups}</p:childTnLst></p:cTn>'
    '<p:prevCondLst><p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>'
    '<p:nextCondLst><p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst>'
    '</p:seq></p:childTnLst></p:cTn></p:par></p:tnLst>'
    '<p:bldLst>{blds}</p:bldLst></p:timing>'
)


def rebuild_timing(old_timing):
    effects = []
    for m in EFFECT_PAR.finditer(old_timing):
        block = m.group(0)
        spid = re.search(r'spid="(\d+)"', block)
        if not spid:
            continue
        # 提取 <p:childTnLst>...</p:childTnLst> 内层（set + animEffect）
        inner = re.search(r'<p:childTnLst>(.*)</p:childTnLst>', block, re.S)
        if not inner:
            continue
        effects.append((spid.group(1), inner.group(1)))
    if not effects:
        return None
    nid = 2
    groups = []
    for spid, inner in effects:
        nid += 1
        a = nid
        nid += 1
        b = nid
        nid += 1
        c = nid
        nid += 2  # 为 set/animEffect 内部 id 留两个空位
        groups.append(CLICK_TPL.format(a=a, b=b, c=c, inner=inner))
    # 重新分配内部 id（set cBhvr cTn / animEffect cTn）
    xml = ''.join(groups)

    def bump(mm):
        nonlocal nid
        nid += 1
        return 'id="%d"' % nid

    # 内层已有 id 属性的 cTn 统一重编号，避免重复（负向断言防止误伤 spid="N"）
    xml = re.sub(r'(?<![A-Za-z])id="\d+"', bump, xml)
    blds = ''.join('<p:bldP spid="%s" grpId="0"/>' % s for s, _ in effects)
    return SEQ_SKELETON.format(groups=xml, blds=blds)


def main(src, dst):
    zin = zipfile.ZipFile(src)
    stats = []
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if re.match(r'ppt/slides/slide\d+\.xml$', item.filename):
                xml = data.decode('utf-8')
                m = re.search(r'<p:timing>.*</p:timing>', xml, re.S)
                if m:
                    new_timing = rebuild_timing(m.group(0))
                    if new_timing:
                        xml = xml[:m.start()] + new_timing + xml[m.end():]
                        stats.append((item.filename, len(re.findall(
                            r'nodeType="clickEffect"', new_timing))))
                data = xml.encode('utf-8')
            zout.writestr(item, data)
    for fn, n in stats:
        print('%s: %d clicks' % (fn, n))
    print('TOTAL clicks:', sum(n for _, n in stats))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
