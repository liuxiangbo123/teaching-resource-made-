# -*- coding: utf-8 -*-
"""COM 双指标验证：每页动画数量 + 首个效果触发方式必须为单击(onPageClick=1)。
用法: python com_verify.py <file.pptx>
输出 JSON: [{"slide": n, "count": x, "firstTrigger": y}, ...]
"""
import sys, json, os

PS_SCRIPT = r'''
param($path)
$pp = New-Object -ComObject PowerPoint.Application
$pres = $pp.Presentations.Open($path, $true, $false, $false)
$results = @()
foreach ($slide in $pres.Slides) {
    $ms = $slide.TimeLine.MainSequence
    $trig = -1
    if ($ms.Count -gt 0) { $trig = $ms.Item(1).Timing.TriggerType }
    $results += [PSCustomObject]@{ slide = $slide.SlideIndex; count = $ms.Count; firstTrigger = $trig }
}
$pres.Close()
$pp.Quit()
$results | ConvertTo-Json -Compress
'''

def main():
    path = os.path.abspath(sys.argv[1])
    ps_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_com_verify_run.ps1")
    with open(ps_file, "w", encoding="utf-8-sig") as f:
        f.write(PS_SCRIPT)
    import subprocess
    r = subprocess.run(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps_file, "-path", path],
        capture_output=True, text=True, timeout=300)
    out = r.stdout.strip()
    # 单页时 ConvertTo-Json 输出单个对象而非数组
    data = json.loads(out) if out else []
    if isinstance(data, dict): data = [data]
    print(json.dumps(data, ensure_ascii=False))
    os.remove(ps_file)

if __name__ == "__main__":
    main()
